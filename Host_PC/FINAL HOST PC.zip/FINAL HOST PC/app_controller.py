import threading
import time
import sys

# Import the tools we built in the previous steps
from tcp_client import send_bitstream 
from mqtt_client import FPGAMessenger

class TrafficController:
    def __init__(self, pi_ip):
        self.pi_ip = pi_ip
        self.is_uploading = False
        self.messenger = None

    def upload_bitstream_thread(self, file_path):
        print(f"\n[*] Starting background thread for TCP upload...")
        self.is_uploading = True # Lock the system
        
        try:
            # Call the blocking TCP function
            success = send_bitstream(file_path, self.pi_ip, target_port=5001)
            
            if success:
                print("\n[+] FPGA Programming Complete! Ready for live streaming.")
                self.start_live_streaming()
            else:
                print("\n[!] FPGA Programming Failed. Check the network and try again.")
        finally:
            # --- NEW: THE RETRY FIX ---
            # This ensures the flag is ALWAYS reset, even if a Broken Pipe crash happens.
            self.is_uploading = False

    def trigger_upload(self, file_path):
        """Spins up a new thread specifically for the heavy file transfer."""
        if self.is_uploading:
            print("[!] An upload is already in progress.")
            return

        # Create and start the background thread
        upload_thread = threading.Thread(
            target=self.upload_bitstream_thread, 
            args=(file_path,),
            daemon=True # Daemon threads close automatically when the main program exits
        )
        upload_thread.start()

    def start_live_streaming(self):
        """Initializes the MQTT client, which starts its own listening thread."""
        if self.messenger:
            print("[*] Live stream is already active.")
            return # <-- ADD THIS to protect the existing Flask hook
        
        # Hardcode the HiveMQ address here so it ignores the Pi's local IP
        self.messenger = FPGAMessenger(broker_ip="broker.hivemq.com")
        
        # connect_and_start() uses loop_start() internally, which spins up a thread!
        if self.messenger.connect_and_start():
            print("\n[*] Live streaming channels open. You can now send ALSU commands.")
        else:
            print("\n[!] Failed to establish live streaming connection.")

    def run_cli_loop(self):
        """
        The Main Thread. 
        Because TCP and MQTT are on background threads, this loop is free 
        to instantly respond to user input without ever freezing.
        """
        print("==========================================")
        print("        HIL FPGA Master Controller        ")
        print("==========================================")
        print("Commands:")
        print("  upload <filepath>  - Send .bit file to program FPGA")
        print("  send <op,A,B>      - Send live data to ALSU (e.g., send ADD,5,3)")
        print("  exit               - Quit the application")
        
        while True:
            try:
                # The input() function blocks the MAIN thread, but our background 
                # threads keep running and receiving network data perfectly!
                cmd_raw = input("\n> ").strip()
                if not cmd_raw:
                    continue
                    
                parts = cmd_raw.split(" ")
                action = parts[0].lower()

                if action == "exit":
                    print("[*] Shutting down traffic controller...")
                    if self.messenger:
                        self.messenger.stop()
                    sys.exit(0)

                elif action == "upload" and len(parts) > 1:
                    filepath = parts[1]
                    self.trigger_upload(filepath)

                elif action == "send" and len(parts) > 1:
                    if not self.messenger:
                        print("[!] You must successfully upload the bitstream first.")
                        continue
                        
                    data = parts[1].split(",")
                    if len(data) == 3:
                        self.messenger.send_input(data[0], data[1], data[2])
                    else:
                        print("[!] Invalid format. Use: send ADD,5,3")
                else:
                    print("[!] Unknown command.")

            except KeyboardInterrupt:
                print("\n[*] Force quitting...")
                if self.messenger:
                    self.messenger.stop()
                sys.exit(0)

# --- Execution ---
if __name__ == "__main__":
    # In a real scenario, you'd use argparse to get the IP, just like previous scripts
    target_ip = "127.0.0.1" 
    controller = TrafficController(target_ip)
    controller.run_cli_loop()
