from flask import Flask, request, jsonify, render_template
from app_controller import TrafficController
from tcp_client import send_bitstream
import threading 
import os
import atexit  # NEW: Triggers a clean shutdown when you close the app

app = Flask(__name__, template_folder='.')
# Initialize your existing controller 
controller = TrafficController(pi_ip="100.70.152.108") 
controller.start_live_streaming() # Start MQTT listener

# --- Bridge the MQTT result to Flask ---
latest_result = None
result_event = threading.Event()

def mqtt_gui_hook(payload):
    """This grabs the data from the background MQTT thread and wakes up Flask"""
    global latest_result
    latest_result = payload
    result_event.set() # Unblock the route!

# Attach the hook to your messenger
controller.messenger.gui_output_callback = mqtt_gui_hook

# --- NEW: The Defense Against Zombie Ports ---
def cleanup_network_threads():
    """Forces the background network threads to close and release ports."""
    print("\n[*] Shutting down background network threads...")
    if controller.messenger:
        controller.messenger.stop()

# Tell Python to run the cleanup function the exact moment the script exits
atexit.register(cleanup_network_threads)
# ---------------------------------------------

@app.route('/')
def index():
    # Serves your HTML file (save your HTML as index.html in the same folder)
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_bitstream():
    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "No file part"}), 400
    
    file = request.files['file']
    filepath = f"./temp_{file.filename}"
    file.save(filepath)
    
    # Block and wait for the actual TCP transfer to finish!
    # (Optional: Use your robust_tcp_upload from safety_net.py here instead)
    success, message = send_bitstream(filepath, controller.pi_ip, 5001)
    
    if success:
        return jsonify({"status": "success", "message": "FPGA Programmed Successfully"})
    else:
        return jsonify({"status": "error", "message": message}), 500 # Send HTTP 500 error

@app.route('/api/calculate', methods=['POST'])
def calculate():
    global latest_result
    data = request.json
    raw_op = data.get('operator')
    a = data.get('operandA')
    b = data.get('operandB')
    
    # Map GUI symbols to FPGA Opcodes
    op_map = {
        "+": "ADD", 
        "-": "SUB", 
        "x": "MUL", 
        "Shift": "SHF", # Ensure these match what your Pi actually expects
        "XOR": "XOR", 
        "Bypass": "BYP"
    }
    opcode = op_map.get(raw_op, raw_op) 
    
    result_event.clear()
    controller.messenger.send_input(opcode, a, b) # Send the mapped opcode
    
    # Wait up to 5 seconds for the Pi to reply via MQTT
    success = result_event.wait(timeout=5.0)
    
    if success:
        return jsonify({"status": "success", "result": latest_result})
    else:
        return jsonify({"status": "error", "message": "Pi Timeout - No response received"})

if __name__ == '__main__':
    print("[*] Starting Local HIL Server on http://127.0.0.1:5002")
    # --- NEW: use_reloader=False prevents duplicate zombie threads ---
    app.run(debug=True, port=5002, use_reloader=False)