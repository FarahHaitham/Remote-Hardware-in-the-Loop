import time
import socket
import paho.mqtt.client as mqtt

# --- 1. The TCP Safety Net (Retries & Backoff) ---

def robust_tcp_upload(upload_function, file_path, ip, port, max_retries=3):
    """
    Wraps your TCP upload function in a protective retry loop.
    If the connection fails, it waits and tries again before giving up.
    """
    attempt = 1
    wait_time = 2  # Start with a 2-second wait

    while attempt <= max_retries:
        print(f"[*] Upload Attempt {attempt}/{max_retries}...")
        
        # Try to run the upload function you wrote earlier
        success, message = upload_function(file_path, ip, port)
        
        if success:
            return True, message
            
        print(f"[!] Attempt {attempt} failed: {message}")
        
        if attempt == max_retries:
            break
            
        print(f"[*] Retrying in {wait_time} seconds...\n")
        time.sleep(wait_time)
        wait_time *= 2  # Exponential backoff (wait 2s, then 4s, etc.)
        attempt += 1

    return False, "CRITICAL: Upload failed after maximum retries. Please check Raspberry Pi power and WiFi."


# --- 2. The MQTT Safety Net (State Tracking) ---

class NetworkStateMonitor:
    """
    An addition to your FPGAMessenger class. 
    It explicitly tracks network health so the GUI can display a green/red status light.
    """
    def __init__(self):
        # Possible states: "DISCONNECTED", "CONNECTING", "CONNECTED", "RECONNECTING"
        self.current_state = "DISCONNECTED"
        self.gui_status_callback = None  # Hook for the A1 engineer

    def update_state(self, new_state):
        self.current_state = new_state
        print(f"[NETWORK STATUS] -> {self.current_state}")
        
        # Push the new state to the GUI if A1 attached a function
        if self.gui_status_callback:
            self.gui_status_callback(self.current_state)

    # These functions should be linked to your paho-mqtt callbacks
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.update_state("CONNECTED")
        else:
            self.update_state("FAILED_TO_CONNECT")

    def on_disconnect(self, client, userdata, rc):
        if rc != 0:
            # rc != 0 means it was an unexpected drop (e.g., WiFi died)
            self.update_state("RECONNECTING")
            print("[!] Warning: Unexpected network drop. Auto-recovering...")
        else:
            self.update_state("DISCONNECTED")
