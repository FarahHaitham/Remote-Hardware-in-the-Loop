import paho.mqtt.client as mqtt
import json
import time
import uuid

class FPGAMessenger:
    def __init__(self, broker_ip, broker_port=1883):
        """
        Initializes the MQTT Client.
        Default MQTT port is 1883.
        """
        self.broker_ip = broker_ip
        self.broker_port = broker_port
        
        # Create an MQTT client instance
        # Using a unique Client ID prevents disconnect loops
        # Generate a unique ID every time the app launches
        unique_id = uuid.uuid4().hex[:8]
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"PC_Backend_HIL_{unique_id}")
        
        # Attach internal callback functions
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.on_disconnect = self._on_disconnect
        
        # This is the "hook" the A1 GUI engineer will use to get data
        self.gui_output_callback = None 

    def connect_and_start(self):
        """Connects to the broker and starts the background listening thread."""
        try:
            print(f"[*] Connecting to MQTT Broker at {self.broker_ip}:{self.broker_port}...")
            self.client.connect(self.broker_ip, self.broker_port, keepalive=60)
            
            # loop_start() spins up a background thread! 
            # This satisfies your multithreading requirement perfectly.
            self.client.loop_start() 
            return True
        except Exception as e:
            print(f"[!] MQTT Connection Error: {e}")
            return False

    def _on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            print("[+] Successfully connected to HiveMQ Broker.")
            # Subscribe to the specific output topic
            self.client.subscribe("tony_fpga_project_77x/output")
            print("[*] Subscribed to topic: tony_fpga_project_77x/output")
        else:
            print(f"[!] Failed to connect. Return code: {reason_code}")

    def _on_disconnect(self, client, userdata, disconnect_flags, reason_code, properties):
        """Triggered if the network drops."""
        print("[!] Disconnected from MQTT Broker. Attempting to auto-reconnect...")

    def _on_message(self, client, userdata, msg):
        """Triggered automatically whenever a message arrives on 'alsu/output'."""
        payload = msg.payload.decode('utf-8')
        print(f"[>] Incoming Output: {payload}")
        
        # If A1 provided a GUI update function, send the data to their GUI
        if self.gui_output_callback:
            self.gui_output_callback(payload)

    def send_input(self, opcode, opA, opB):
        """
        Called by the GUI when the user clicks 'Calculate/Send'.
        Formats the data and publishes it to the Pi.
        """
        # Formatting as JSON is highly recommended for structured data
        payload_dict = {
            "opcode": opcode,
            "opA": opA,
            "opB": opB
        }
        json_payload = json.dumps(payload_dict)
        
        # Publish to the specific input topic
        self.client.publish("tony_fpga_project_77x/input", json_payload)
        print(f"[<] Sent Input: {json_payload}")

    def stop(self):
        """Cleanly shuts down the network threads."""
        self.client.loop_stop()
        self.client.disconnect()


# --- CLI Execution & Testing Block ---
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="HIL MQTT Live Stream Test")
    parser.add_argument("-i", "--ip", required=True, help="IP of the Raspberry Pi Broker")
    args = parser.parse_args()

    # 1. Initialize
    messenger = FPGAMessenger(broker_ip=args.ip)
    
    # 2. Connect
    if messenger.connect_and_start():
        try:
            print("\n[*] Live streaming active. Type 'exit' to quit.")
            while True:
                # 3. Simulate GUI input from the terminal
                user_cmd = input("\nEnter Opcode, A, B (comma separated) or 'exit': ")
                if user_cmd.lower() == 'exit':
                    break
                
                parts = user_cmd.split(',')
                if len(parts) == 3:
                    messenger.send_input(parts[0].strip(), parts[1].strip(), parts[2].strip())
                else:
                    print("[!] Invalid format. Example: ADD, 5, 3")
                    
                time.sleep(0.5) # Give the background thread a moment to print the reply
                
        except KeyboardInterrupt:
            pass
        finally:
            messenger.stop()
            print("[*] Shutdown complete.")
