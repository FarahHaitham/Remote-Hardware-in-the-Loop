import socket
import os
import time

def packetize_bitstream(file_path, chunk_size=1024):
    """Generates chunks of the file to prevent memory overload."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Error: Could not find '{file_path}'")

    file_size = os.path.getsize(file_path)
    bytes_read = 0

    with open(file_path, 'rb') as bit_file:
        while True:
            chunk = bit_file.read(chunk_size)
            if not chunk:
                break
            bytes_read += len(chunk)
            yield chunk, bytes_read, file_size

def send_bitstream(file_path, target_ip, target_port=5001, progress_callback=None):
    """
    Handles TCP connection and sends the file.
    
    Args:
        file_path (str): Path to the .bit file.
        target_ip (str): IP of the Raspberry Pi.
        target_port (int): TCP port to connect to.
        progress_callback (function): An optional function to update the GUI.
    
    Returns:
        tuple: (Success_Boolean, Status_Message)
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
            client_socket.settimeout(10.0)
            
            # 1. Connect
            client_socket.connect((target_ip, target_port))
            
            # 2. Handshake (Discuss this with B2!)
            total_size = os.path.getsize(file_path)
            client_socket.sendall(f"SIZE:{total_size}\n".encode('utf-8'))
            
            ack = client_socket.recv(1024).decode('utf-8')
            if "READY" not in ack:
                return False, "Raspberry Pi rejected the handshake."

            # 3. Transmission
            for chunk, bytes_sent, total_bytes in packetize_bitstream(file_path):
                client_socket.sendall(chunk)
                
                # If the GUI engineer provided a callback, send the data to their progress bar
                if progress_callback:
                    progress_callback(bytes_sent, total_bytes)
                else:
                    # Otherwise, just print to the terminal for your CLI
                    progress = (bytes_sent / total_bytes) * 100
                    print(f"\rSending: {progress:.1f}%", end="")

            # 4. Final Confirmation
            final_ack = client_socket.recv(1024).decode('utf-8')
            if "SUCCESS" in final_ack:
                return True, "File transferred successfully."
            else:
                return False, f"Pi reported an error: {final_ack}"

    except ConnectionRefusedError:
        return False, f"Connection refused on {target_ip}:{target_port}. Is the server running?"
    except socket.timeout:
        return False, "Network timeout. The Pi took too long to respond."
    except Exception as e:
        return False, f"Unexpected error: {str(e)}"

# --- CLI Execution Block ---
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Send .bit file to Raspberry Pi")
    parser.add_argument("-f", "--file", required=True, help="Path to .bit file")
    parser.add_argument("-i", "--ip", required=True, help="IP address of Raspberry Pi")
    parser.add_argument("-p", "--port", type=int, default=5001, help="TCP Port")
    args = parser.parse_args()

    # Run the function
    print(f"Connecting to {args.ip}...")
    success, message = send_bitstream(args.file, args.ip, args.port)
    
    print(f"\nResult: {message}")
