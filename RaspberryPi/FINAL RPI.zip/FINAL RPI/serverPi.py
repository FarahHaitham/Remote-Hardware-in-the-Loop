import time
import os
from tcp_serverPi import start_tcp_listener
from mqtt_clientPi import FPGADeviceClient

def program_fpga(bitfile_path):
    """
    This is where you execute the actual hardware programming.
    Depending on your FPGA (Xilinx, Altera, Gowin), you will call a shell command here.
    """
    print(f"\n[*] Executing Hardware Programming Sequence...")
    # Example for Xilinx Zynq:
    # os.system(f"fpgautil -b {bitfile_path}")
    
    # Simulating the programming time
    time.sleep(2)
    print("[+] FPGA Programming Successful!")

def main():
    print("==========================================")
    print("       Raspberry Pi HIL Receiver          ")
    print("==========================================")
    
    bitfile_save_path = "/tmp/SPI_ALSU_V2.bit" # Change to your Pi's actual path
    
    # 1. Start the MQTT Client in the background (Ready to chat)
    mqtt_client = FPGADeviceClient()
    mqtt_client.connect_and_start()
    
    try:
        while True:
            # 2. Block and wait for a new bitstream upload via TCP
            # "0.0.0.0" means listen on all network interfaces
            print("\n[*] Ready for new FPGA bitstream upload...")
            upload_success = start_tcp_listener(listen_ip="0.0.0.0", 
                                              listen_port=5001, 
                                              save_path=bitfile_save_path)
            
            # 3. If file received, program the FPGA
            if upload_success:
                program_fpga(bitfile_save_path)
                print("[*] Hardware ready. Awaiting instructions from PC GUI via MQTT...")
            else:
                print("[!] Upload failed. Waiting for PC to retry...")
                time.sleep(2)
                
            # The loop continues. It will keep the MQTT connection alive to do math,
            # while simultaneously listening on TCP in case you upload a newer .bit file!

    except KeyboardInterrupt:
        print("\n[*] Shutting down Pi Server...")
    finally:
        mqtt_client.stop()

if __name__ == "__main__":
    main()