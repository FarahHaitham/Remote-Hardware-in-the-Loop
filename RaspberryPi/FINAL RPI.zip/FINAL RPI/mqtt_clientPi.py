import paho.mqtt.client as mqtt
import spidev
import json
import time
import uuid

class FPGADeviceClient:
    def __init__(self, broker_ip="broker.hivemq.com", broker_port=1883):
        self.broker_ip = broker_ip
        self.broker_port = broker_port
        
        # Unique ID prevents HiveMQ disconnect loops
        unique_id = uuid.uuid4().hex[:8]
        self.client = mqtt.Client(client_id=f"Pi_Hardware_{unique_id}", protocol=mqtt.MQTTv311)
        
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        
        # Topics must perfectly match the PC
        self.input_topic = "tony_fpga_project_77x/input"
        self.output_topic = "tony_fpga_project_77x/output"
        
        # --- SPI INITIALIZATION ---
        try:
            self.spi = spidev.SpiDev()
            self.spi.open(0, 0)
            self.spi.max_speed_hz = 1000000  # 1 MHz
            self.spi.mode = 0b00             # Mode 0
            self.spi.lsbfirst = False        # MSB first
            print("[+] SPI Bus 0, Device 0 Initialized.")
        except Exception as e:
            print(f"[!] CRITICAL: Could not open SPI bus. Is SPI enabled in raspi-config? Error: {e}")
            self.spi = None

        # --- OPCODE MAPPING ---
        # Translates the PC's string commands into your FPGA's expected integers
        self.opcode_map = {
            "BYP": 0,
            "ADD": 1,
            "SUB": 2,
            "MUL": 3,
            "SHF": 4,
            "XOR": 5
        }

    def connect_and_start(self):
        try:
            print(f"[*] Connecting to HiveMQ Broker...")
            self.client.connect(self.broker_ip, self.broker_port, keepalive=60)
            self.client.loop_start() 
            return True
        except Exception as e:
            print(f"[!] MQTT Connection Error: {e}")
            return False

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print("[+] Pi connected to MQTT Broker.")
            self.client.subscribe(self.input_topic)
            print(f"[*] Subscribed to instructions on: {self.input_topic}")
        else:
            print(f"[!] Failed to connect. Code: {rc}")

    def _on_message(self, client, userdata, msg):
        """Triggered when the PC sends a math operation."""
        payload = msg.payload.decode('utf-8')
        print(f"\n[>] Received Instruction: {payload}")
        
        try:
            data = json.loads(payload)
            text_opcode = data.get("opcode")
            opA = int(data.get("opA", 0))
            opB = int(data.get("opB", 0))
            
            # Convert text (e.g., "ADD") to integer (e.g., 1)
            # Default to Bypass (0) if the string isn't recognized
            int_opcode = self.opcode_map.get(text_opcode, 0)
            
            # Call the hardware directly!
            if self.spi:
                result = self._compute_alsu_hardware(int_opcode, opA, opB)
            else:
                print("[!] SPI is down. Returning error code.")
                result = "ERR_SPI"
            
            # Publish result back to PC
            self._send_result(result)
            
        except json.JSONDecodeError:
            print("[!] Received malformed JSON payload.")
        except Exception as e:
            print(f"[!] Processing error: {e}")

    def _compute_alsu_hardware(self, opcode, opA, opB):
        """
        Sends the instruction to the ALSU via SPI and retrieves the 16-bit result.
        """
        print(f"[*] Sending to FPGA -> Op:{opcode}, A:{opA}, B:{opB}")
        
        # We send 5 bytes: [Opcode, A, B, Dummy, Dummy]
        payload = [opcode, opA, opB, 0x00, 0x00]
        
        # xfer2 keeps the Chip Select (CE0) pin pulled LOW
        response = self.spi.xfer2(payload)
        
        # Extract the 16-bit result from the dummy clock bytes
        high_byte = response[3]
        low_byte = response[4]
        
        final_result = (high_byte << 8) | low_byte
        return final_result

    def _send_result(self, result):
        """Sends the calculation back to the PC GUI."""
        payload = str(result)
        self.client.publish(self.output_topic, payload)
        print(f"[<] Sent Result to PC: {payload}")

    def stop(self):
        """Cleanly shuts down network threads and hardware pins."""
        self.client.loop_stop()
        self.client.disconnect()
        if self.spi:
            self.spi.close()
            print("[*] SPI Connection closed.")