import socket
import os

def start_tcp_listener(listen_ip="0.0.0.0", listen_port=5001, save_path="/tmp/fpga_bitstream.bit"):
    """
    Listens for incoming TCP connections. 
    Using /tmp/ bypasses ALL Linux permission issues.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # 0.0.0.0 guarantees it listens to the Tailscale tunnel
            server_socket.bind((listen_ip, listen_port))
            server_socket.listen(1)
            
            print(f"[*] TCP Server listening on port {listen_port}. Waiting for bitstream...")
            
            # The code pauses right here and waits for your PC
            conn, addr = server_socket.accept()
            
            with conn:
                print(f"\n[+] Connection accepted from {addr}!")
                
                # 1. Wait for Handshake
                handshake = conn.recv(1024).decode('utf-8').strip()
                if not handshake.startswith("SIZE:"):
                    print("[!] Invalid handshake received.")
                    conn.sendall(b"ERROR: Invalid Handshake\n")
                    return False
                
                expected_size = int(handshake.split(":")[1])
                print(f"[*] Handshake complete. Incoming file size: {expected_size} bytes")
                
                # 2. Reply READY
                conn.sendall(b"READY\n")
                
                # 3. Receive the file in chunks
                bytes_received = 0
                with open(save_path, 'wb') as bit_file:
                    while bytes_received < expected_size:
                        chunk = conn.recv(1024) # The 1024 VPN tunnel size!
                        if not chunk:
                            print("[!] Connection dropped mid-transfer.")
                            break 
                        bit_file.write(chunk)
                        bytes_received += len(chunk)
                
                # 4. Verify and Confirm
                if bytes_received == expected_size:
                    print(f"[+] Bitstream received successfully. Saved to {save_path}")
                    conn.sendall(b"SUCCESS\n")
                    return True
                else:
                    print(f"[!] File incomplete. Got {bytes_received}/{expected_size}")
                    conn.sendall(b"ERROR: Incomplete File\n")
                    return False
                    
    except Exception as e:
        print(f"[!] TCP Server Error: {e}")
        return False